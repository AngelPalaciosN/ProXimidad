"use client"

import { createContext, useContext, useState, useEffect } from "react"
import axios from "axios"
import { useRouter } from "next/navigation"

const AuthContext = createContext()

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState(null)
  const router = useRouter()

  // Usar la variable de entorno de Vite
  const baseUrl = process.env.NEXT_PUBLIC_API_BASE_URL || "http://localhost:8000"

  useEffect(() => {
    // Check for token in local storage and validate it
    const token = localStorage.getItem("token")
    if (token) {
      validateToken(token)
    }
  }, [])

  const validateToken = async (token) => {
    setLoading(true)
    try {
      const response = await axios.get(`${baseUrl}/usuarios/perfil/`, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })
      setUser(response.data)
      localStorage.setItem("token", token)
    } catch (error) {
      setUser(null)
      localStorage.removeItem("token")
    } finally {
      setLoading(false)
    }
  }

  const register = async (formData) => {
    setLoading(true)
    setError(null)
    try {
      const response = await axios.post(`${baseUrl}/usuarios/registrar/`, formData)
      const { token } = response.data
      localStorage.setItem("token", token)
      await validateToken(token)
      return { success: true }
    } catch (err) {
      setError(err.response?.data?.message || "No se pudo registrar el usuario")
      return { success: false, error: err.response?.data?.message }
    } finally {
      setLoading(false)
    }
  }

  const loginWithCode = async (formData) => {
    setLoading(true)
    setError(null)
    try {
      const response = await axios.post(`${baseUrl}/usuarios/login/`, formData)
      const { token } = response.data
      localStorage.setItem("token", token)
      await validateToken(token)
      return { success: true }
    } catch (err) {
      setError(err.response?.data?.message || "Credenciales incorrectas")
      return { success: false, error: err.response?.data?.message }
    } finally {
      setLoading(false)
    }
  }

  const generateCode = async (email) => {
    setLoading(true)
    setError(null)
    try {
      await axios.post(`${baseUrl}/usuarios/generar-codigo/`, { correo_electronico: email })
      return { success: true }
    } catch (err) {
      setError(err.response?.data?.message || "Error al generar el código")
      return { success: false, error: err.response?.data?.message }
    } finally {
      setLoading(false)
    }
  }

  const updateProfile = async (formData) => {
    setLoading(true)
    setError(null)
    try {
      const token = localStorage.getItem("token")
      const response = await axios.put(`${baseUrl}/usuarios/perfil/`, formData, {
        headers: {
          Authorization: `Bearer ${token}`,
        },
      })

      // Update user state with new data
      setUser(response.data)
      return { success: true }
    } catch (err) {
      setError(err.response?.data?.message || "No se pudo actualizar el perfil")
      return { success: false, error: err.response?.data?.message }
    } finally {
      setLoading(false)
    }
  }

  const logout = () => {
    setUser(null)
    localStorage.removeItem("token")
    router.push("/")
  }

  const value = {
    user,
    loading,
    error,
    register,
    loginWithCode,
    generateCode,
    updateProfile,
    logout,
  }

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>
}

export const useAuth = () => {
  return useContext(AuthContext)
}
