"use client"

import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { ArrowUpRight, Briefcase, Clock, DollarSign, Edit, Filter, Plus, Search, Star, Trash2 } from "lucide-react"
import Link from "next/link"

export default function ServicesPage() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-30 flex h-16 items-center gap-4 border-b bg-background px-4 md:px-6">
        <Link href="/dashboard" className="flex items-center gap-2 font-semibold">
          <Package2 className="h-6 w-6" />
          <span>ProXimidad</span>
        </Link>
        <nav className="hidden flex-1 md:flex">
          <ul className="flex flex-1 items-center gap-4 text-sm font-medium">
            <li>
              <Link href="/dashboard" className="flex items-center gap-2 text-muted-foreground hover:text-primary">
                Dashboard
              </Link>
            </li>
            <li>
              <Link href="/services" className="flex items-center gap-2 text-primary">
                My Services
              </Link>
            </li>
            <li>
              <Link
                href="/dashboard/clients"
                className="flex items-center gap-2 text-muted-foreground hover:text-primary"
              >
                Clients
              </Link>
            </li>
            <li>
              <Link
                href="/dashboard/messages"
                className="flex items-center gap-2 text-muted-foreground hover:text-primary"
              >
                Messages
              </Link>
            </li>
            <li>
              <Link href="/profile" className="flex items-center gap-2 text-muted-foreground hover:text-primary">
                Profile
              </Link>
            </li>
          </ul>
        </nav>
        <div className="flex flex-1 items-center justify-end gap-4 md:flex-initial">
          <Button>
            <Plus className="mr-2 h-4 w-4" />
            Add New Service
          </Button>
        </div>
      </header>
      <main className="flex-1 space-y-4 p-4 md:p-8">
        <div className="flex items-center justify-between">
          <h1 className="text-2xl font-bold tracking-tight">My Services</h1>
          <div className="flex items-center gap-2">
            <div className="relative">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input type="search" placeholder="Search services..." className="w-[200px] pl-8 md:w-[260px]" />
            </div>
            <Button variant="outline" size="icon">
              <Filter className="h-4 w-4" />
              <span className="sr-only">Filter</span>
            </Button>
          </div>
        </div>
        <Tabs defaultValue="active">
          <TabsList>
            <TabsTrigger value="active">Active</TabsTrigger>
            <TabsTrigger value="draft">Drafts</TabsTrigger>
            <TabsTrigger value="archived">Archived</TabsTrigger>
          </TabsList>
          <TabsContent value="active" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <Card>
                <CardHeader className="pb-2">
                  <div className="flex justify-between">
                    <Badge>Popular</Badge>
                    <Button variant="ghost" size="icon">
                      <Edit className="h-4 w-4" />
                    </Button>
                  </div>
                  <CardTitle>Web Application Development</CardTitle>
                  <CardDescription>Full-stack web applications</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between">
                    <div className="space-y-1">
                      <div className="text-sm text-muted-foreground">Starting at</div>
                      <div className="flex items-center text-2xl font-bold">
                        <DollarSign className="h-4 w-4" />
                        2,500
                      </div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-sm text-muted-foreground">Delivery time</div>
                      <div className="flex items-center text-lg font-medium">
                        <Clock className="mr-1 h-4 w-4" />
                        2-4 weeks
                      </div>
                    </div>
                  </div>
                  <div className="mt-4 text-sm text-muted-foreground">
                    Custom web applications built with React, Node.js, and your choice of database. Includes responsive
                    design, user authentication, and basic admin features.
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Briefcase className="mr-1 h-4 w-4" />8 active projects
                  </div>
                  <div className="flex items-center gap-1">
                    <Star className="h-4 w-4 fill-primary text-primary" />
                    <span className="text-sm font-medium">4.9</span>
                    <span className="text-sm text-muted-foreground">(28)</span>
                  </div>
                </CardFooter>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <div className="flex justify-between">
                    <Badge variant="outline">New</Badge>
                    <Button variant="ghost" size="icon">
                      <Edit className="h-4 w-4" />
                    </Button>
                  </div>
                  <CardTitle>API Development</CardTitle>
                  <CardDescription>RESTful or GraphQL APIs</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between">
                    <div className="space-y-1">
                      <div className="text-sm text-muted-foreground">Starting at</div>
                      <div className="flex items-center text-2xl font-bold">
                        <DollarSign className="h-4 w-4" />
                        1,200
                      </div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-sm text-muted-foreground">Delivery time</div>
                      <div className="flex items-center text-lg font-medium">
                        <Clock className="mr-1 h-4 w-4" />
                        1-2 weeks
                      </div>
                    </div>
                  </div>
                  <div className="mt-4 text-sm text-muted-foreground">
                    Custom API development with Node.js, Express, and MongoDB or PostgreSQL. Includes authentication,
                    rate limiting, and comprehensive documentation.
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Briefcase className="mr-1 h-4 w-4" />3 active projects
                  </div>
                  <div className="flex items-center gap-1">
                    <Star className="h-4 w-4 fill-primary text-primary" />
                    <span className="text-sm font-medium">5.0</span>
                    <span className="text-sm text-muted-foreground">(5)</span>
                  </div>
                </CardFooter>
              </Card>
              <Card>
                <CardHeader className="pb-2">
                  <div className="flex justify-between">
                    <Badge variant="secondary">Best Value</Badge>
                    <Button variant="ghost" size="icon">
                      <Edit className="h-4 w-4" />
                    </Button>
                  </div>
                  <CardTitle>UI/UX Design</CardTitle>
                  <CardDescription>Modern user interfaces</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between">
                    <div className="space-y-1">
                      <div className="text-sm text-muted-foreground">Starting at</div>
                      <div className="flex items-center text-2xl font-bold">
                        <DollarSign className="h-4 w-4" />
                        800
                      </div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-sm text-muted-foreground">Delivery time</div>
                      <div className="flex items-center text-lg font-medium">
                        <Clock className="mr-1 h-4 w-4" />1 week
                      </div>
                    </div>
                  </div>
                  <div className="mt-4 text-sm text-muted-foreground">
                    Clean, modern UI design with a focus on usability and conversion. Includes wireframes, mockups, and
                    interactive prototypes.
                  </div>
                </CardContent>
                <CardFooter className="flex justify-between">
                  <div className="flex items-center text-sm text-muted-foreground">
                    <Briefcase className="mr-1 h-4 w-4" />5 active projects
                  </div>
                  <div className="flex items-center gap-1">
                    <Star className="h-4 w-4 fill-primary text-primary" />
                    <span className="text-sm font-medium">4.8</span>
                    <span className="text-sm text-muted-foreground">(12)</span>
                  </div>
                </CardFooter>
              </Card>
            </div>
          </TabsContent>
          <TabsContent value="draft" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <Card>
                <CardHeader className="pb-2">
                  <div className="flex justify-between">
                    <Badge variant="outline">Draft</Badge>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="icon">
                        <Edit className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <CardTitle>Mobile App Development</CardTitle>
                  <CardDescription>iOS and Android applications</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between">
                    <div className="space-y-1">
                      <div className="text-sm text-muted-foreground">Starting at</div>
                      <div className="flex items-center text-2xl font-bold">
                        <DollarSign className="h-4 w-4" />
                        3,500
                      </div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-sm text-muted-foreground">Delivery time</div>
                      <div className="flex items-center text-lg font-medium">
                        <Clock className="mr-1 h-4 w-4" />
                        4-6 weeks
                      </div>
                    </div>
                  </div>
                  <div className="mt-4 text-sm text-muted-foreground">
                    Native mobile applications for iOS and Android using React Native. Includes user authentication,
                    offline functionality, and app store submission.
                  </div>
                </CardContent>
                <CardFooter>
                  <Button className="w-full">Publish Service</Button>
                </CardFooter>
              </Card>
            </div>
          </TabsContent>
          <TabsContent value="archived" className="space-y-4">
            <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
              <Card>
                <CardHeader className="pb-2">
                  <div className="flex justify-between">
                    <Badge variant="outline">Archived</Badge>
                    <div className="flex gap-1">
                      <Button variant="ghost" size="icon">
                        <ArrowUpRight className="h-4 w-4" />
                      </Button>
                      <Button variant="ghost" size="icon">
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                  <CardTitle>WordPress Development</CardTitle>
                  <CardDescription>Custom WordPress sites</CardDescription>
                </CardHeader>
                <CardContent>
                  <div className="flex justify-between">
                    <div className="space-y-1">
                      <div className="text-sm text-muted-foreground">Starting at</div>
                      <div className="flex items-center text-2xl font-bold">
                        <DollarSign className="h-4 w-4" />
                        600
                      </div>
                    </div>
                    <div className="space-y-1">
                      <div className="text-sm text-muted-foreground">Delivery time</div>
                      <div className="flex items-center text-lg font-medium">
                        <Clock className="mr-1 h-4 w-4" />1 week
                      </div>
                    </div>
                  </div>
                  <div className="mt-4 text-sm text-muted-foreground">
                    Custom WordPress websites with responsive design, SEO optimization, and content management system
                    setup.
                  </div>
                </CardContent>
                <CardFooter>
                  <Button variant="outline" className="w-full">
                    Restore Service
                  </Button>
                </CardFooter>
              </Card>
            </div>
          </TabsContent>
        </Tabs>
      </main>
    </div>
  )
}

function Package2(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M3 9h18v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9Z" />
      <path d="m3 9 2.45-4.9A2 2 0 0 1 7.24 3h9.52a2 2 0 0 1 1.8 1.1L21 9" />
      <path d="M12 3v6" />
    </svg>
  )
}
