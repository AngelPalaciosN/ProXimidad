"use client"

import UsuarioList from "@/components/UsuarioList"

export default function UsuariosPage() {
  return <UsuarioList />
}
