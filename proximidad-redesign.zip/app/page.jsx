"use client"

import "../styles/globals.scss"
import Header from "@/components/Header"
import Sec1 from "@/components/Sec1"
import Sec2 from "@/components/Sec2"
import Sec3 from "@/components/Sec3"
import Footer from "@/components/Footer"

export default function Home() {
  return (
    <div className="proximidad-app">
      <Header />
      <main>
        <Sec1 />
        <Sec2 />
        <Sec3 />
      </main>
      <Footer />
    </div>
  )
}
