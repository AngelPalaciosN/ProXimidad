"use client"

import BuscarS from "@/components/BuscarS"

export default function ServiciosPage() {
  return <BuscarS />
}
