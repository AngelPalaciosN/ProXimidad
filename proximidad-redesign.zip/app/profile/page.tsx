"use client"

import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import {
  ArrowUpRight,
  Award,
  Briefcase,
  Calendar,
  Clock,
  Edit,
  ExternalLink,
  Globe,
  Linkedin,
  Mail,
  MapPin,
  Phone,
  Star,
  Twitter,
} from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function ProfilePage() {
  return (
    <div className="flex min-h-screen flex-col">
      <header className="sticky top-0 z-30 flex h-16 items-center gap-4 border-b bg-background px-4 md:px-6">
        <Link href="/dashboard" className="flex items-center gap-2 font-semibold">
          <Package2 className="h-6 w-6" />
          <span>ProXimidad</span>
        </Link>
        <nav className="hidden flex-1 md:flex">
          <ul className="flex flex-1 items-center gap-4 text-sm font-medium">
            <li>
              <Link href="/dashboard" className="flex items-center gap-2 text-muted-foreground hover:text-primary">
                Dashboard
              </Link>
            </li>
            <li>
              <Link
                href="/dashboard/services"
                className="flex items-center gap-2 text-muted-foreground hover:text-primary"
              >
                My Services
              </Link>
            </li>
            <li>
              <Link
                href="/dashboard/clients"
                className="flex items-center gap-2 text-muted-foreground hover:text-primary"
              >
                Clients
              </Link>
            </li>
            <li>
              <Link
                href="/dashboard/messages"
                className="flex items-center gap-2 text-muted-foreground hover:text-primary"
              >
                Messages
              </Link>
            </li>
            <li>
              <Link href="/profile" className="flex items-center gap-2 text-primary">
                Profile
              </Link>
            </li>
          </ul>
        </nav>
        <div className="flex flex-1 items-center justify-end gap-4 md:flex-initial">
          <Button variant="outline" size="sm">
            <ExternalLink className="mr-2 h-4 w-4" />
            Public View
          </Button>
          <Avatar>
            <AvatarImage src="/placeholder-user.jpg" alt="User" />
            <AvatarFallback>JP</AvatarFallback>
          </Avatar>
        </div>
      </header>
      <main className="flex-1 space-y-4 p-4 md:p-8">
        <div className="flex flex-col gap-4 md:flex-row">
          <div className="md:w-1/3">
            <Card>
              <CardHeader className="relative">
                <div className="absolute right-4 top-4">
                  <Button variant="ghost" size="icon">
                    <Edit className="h-4 w-4" />
                  </Button>
                </div>
                <div className="flex flex-col items-center">
                  <Avatar className="h-24 w-24">
                    <AvatarImage src="/placeholder-user.jpg" alt="User" />
                    <AvatarFallback>JP</AvatarFallback>
                  </Avatar>
                  <CardTitle className="mt-4">John Peterson</CardTitle>
                  <CardDescription>Full Stack Developer</CardDescription>
                  <div className="mt-2 flex gap-1">
                    <Badge variant="outline" className="text-xs">
                      <Clock className="mr-1 h-3 w-3" /> Available for work
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium">About</h3>
                    <p className="text-sm text-muted-foreground">
                      Full stack developer with 5+ years of experience specializing in React, Node.js, and cloud
                      architecture. Passionate about creating scalable and user-friendly applications.
                    </p>
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium">Contact Information</h3>
                    <div className="grid gap-2">
                      <div className="flex items-center gap-2 text-sm">
                        <Mail className="h-4 w-4 text-muted-foreground" />
                        <span>john.peterson@example.com</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <Phone className="h-4 w-4 text-muted-foreground" />
                        <span>+1 (555) 123-4567</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <MapPin className="h-4 w-4 text-muted-foreground" />
                        <span>San Francisco, CA</span>
                      </div>
                      <div className="flex items-center gap-2 text-sm">
                        <Globe className="h-4 w-4 text-muted-foreground" />
                        <Link href="#" className="text-primary hover:underline">
                          johnpeterson.dev
                        </Link>
                      </div>
                    </div>
                  </div>
                  <div className="space-y-2">
                    <h3 className="text-sm font-medium">Social Profiles</h3>
                    <div className="flex gap-2">
                      <Button variant="outline" size="icon" asChild>
                        <Link href="#">
                          <Linkedin className="h-4 w-4" />
                        </Link>
                      </Button>
                      <Button variant="outline" size="icon" asChild>
                        <Link href="#">
                          <Twitter className="h-4 w-4" />
                        </Link>
                      </Button>
                      <Button variant="outline" size="icon" asChild>
                        <Link href="#">
                          <Github className="h-4 w-4" />
                        </Link>
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
            <Card className="mt-4">
              <CardHeader>
                <CardTitle className="text-base">Professional Badges</CardTitle>
                <CardDescription>Share these on your profiles</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4">
                  <div className="flex items-center gap-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                      <Award className="h-6 w-6 text-primary" />
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-medium">Top Rated Professional</p>
                        <Button size="sm" variant="ghost" className="h-6 w-6 p-0">
                          <ArrowUpRight className="h-3 w-3" />
                        </Button>
                      </div>
                      <div className="flex items-center gap-1">
                        <Star className="h-3 w-3 fill-primary text-primary" />
                        <Star className="h-3 w-3 fill-primary text-primary" />
                        <Star className="h-3 w-3 fill-primary text-primary" />
                        <Star className="h-3 w-3 fill-primary text-primary" />
                        <Star className="h-3 w-3 fill-primary text-primary" />
                      </div>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                      <Clock className="h-6 w-6 text-primary" />
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-medium">Always On Time</p>
                        <Button size="sm" variant="ghost" className="h-6 w-6 p-0">
                          <ArrowUpRight className="h-3 w-3" />
                        </Button>
                      </div>
                      <p className="text-xs text-muted-foreground">100% on-time delivery rate</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary/10">
                      <Briefcase className="h-6 w-6 text-primary" />
                    </div>
                    <div className="space-y-1">
                      <div className="flex items-center gap-2">
                        <p className="text-sm font-medium">Expert Developer</p>
                        <Button size="sm" variant="ghost" className="h-6 w-6 p-0">
                          <ArrowUpRight className="h-3 w-3" />
                        </Button>
                      </div>
                      <p className="text-xs text-muted-foreground">Verified skills and experience</p>
                    </div>
                  </div>
                </div>
              </CardContent>
              <CardFooter>
                <Button variant="outline" className="w-full">
                  Manage Badges
                </Button>
              </CardFooter>
            </Card>
          </div>
          <div className="md:w-2/3">
            <Tabs defaultValue="services">
              <TabsList className="grid w-full grid-cols-4">
                <TabsTrigger value="services">Services</TabsTrigger>
                <TabsTrigger value="portfolio">Portfolio</TabsTrigger>
                <TabsTrigger value="reviews">Reviews</TabsTrigger>
                <TabsTrigger value="experience">Experience</TabsTrigger>
              </TabsList>
              <TabsContent value="services" className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-bold">My Services</h2>
                  <Button>Add New Service</Button>
                </div>
                <div className="grid gap-4 md:grid-cols-2">
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle>Web Application Development</CardTitle>
                      <CardDescription>Full-stack web applications</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex justify-between">
                        <div className="space-y-1">
                          <div className="text-sm text-muted-foreground">Starting at</div>
                          <div className="text-2xl font-bold">$2,500</div>
                        </div>
                        <div className="space-y-1">
                          <div className="text-sm text-muted-foreground">Delivery time</div>
                          <div className="text-lg font-medium">2-4 weeks</div>
                        </div>
                      </div>
                      <div className="mt-4 text-sm text-muted-foreground">
                        Custom web applications built with React, Node.js, and your choice of database. Includes
                        responsive design, user authentication, and basic admin features.
                      </div>
                    </CardContent>
                    <CardFooter className="flex justify-between">
                      <Button variant="outline">Edit</Button>
                      <Button>View Details</Button>
                    </CardFooter>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle>API Development</CardTitle>
                      <CardDescription>RESTful or GraphQL APIs</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex justify-between">
                        <div className="space-y-1">
                          <div className="text-sm text-muted-foreground">Starting at</div>
                          <div className="text-2xl font-bold">$1,200</div>
                        </div>
                        <div className="space-y-1">
                          <div className="text-sm text-muted-foreground">Delivery time</div>
                          <div className="text-lg font-medium">1-2 weeks</div>
                        </div>
                      </div>
                      <div className="mt-4 text-sm text-muted-foreground">
                        Custom API development with Node.js, Express, and MongoDB or PostgreSQL. Includes
                        authentication, rate limiting, and comprehensive documentation.
                      </div>
                    </CardContent>
                    <CardFooter className="flex justify-between">
                      <Button variant="outline">Edit</Button>
                      <Button>View Details</Button>
                    </CardFooter>
                  </Card>
                  <Card>
                    <CardHeader className="pb-2">
                      <CardTitle>UI/UX Design</CardTitle>
                      <CardDescription>Modern user interfaces</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="flex justify-between">
                        <div className="space-y-1">
                          <div className="text-sm text-muted-foreground">Starting at</div>
                          <div className="text-2xl font-bold">$800</div>
                        </div>
                        <div className="space-y-1">
                          <div className="text-sm text-muted-foreground">Delivery time</div>
                          <div className="text-lg font-medium">1 week</div>
                        </div>
                      </div>
                      <div className="mt-4 text-sm text-muted-foreground">
                        Clean, modern UI design with a focus on usability and conversion. Includes wireframes, mockups,
                        and interactive prototypes.
                      </div>
                    </CardContent>
                    <CardFooter className="flex justify-between">
                      <Button variant="outline">Edit</Button>
                      <Button>View Details</Button>
                    </CardFooter>
                  </Card>
                </div>
              </TabsContent>
              <TabsContent value="portfolio" className="space-y-4">
                <div className="flex items-center justify-between">
                  <h2 className="text-xl font-bold">Portfolio</h2>
                  <Button>Add Project</Button>
                </div>
                <div className="grid gap-6 md:grid-cols-2">
                  <Card>
                    <CardContent className="p-0">
                      <Image
                        src="/placeholder.svg?height=200&width=400"
                        alt="E-commerce Platform"
                        width={400}
                        height={200}
                        className="aspect-video object-cover"
                      />
                      <div className="p-6">
                        <h3 className="text-lg font-bold">E-commerce Platform</h3>
                        <p className="text-sm text-muted-foreground mt-2">
                          A full-featured e-commerce platform with product management, cart functionality, and payment
                          processing.
                        </p>
                        <div className="flex gap-2 mt-4">
                          <Badge variant="secondary">React</Badge>
                          <Badge variant="secondary">Node.js</Badge>
                          <Badge variant="secondary">MongoDB</Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardContent className="p-0">
                      <Image
                        src="/placeholder.svg?height=200&width=400"
                        alt="Task Management App"
                        width={400}
                        height={200}
                        className="aspect-video object-cover"
                      />
                      <div className="p-6">
                        <h3 className="text-lg font-bold">Task Management App</h3>
                        <p className="text-sm text-muted-foreground mt-2">
                          A collaborative task management application with real-time updates and team collaboration
                          features.
                        </p>
                        <div className="flex gap-2 mt-4">
                          <Badge variant="secondary">Vue.js</Badge>
                          <Badge variant="secondary">Express</Badge>
                          <Badge variant="secondary">PostgreSQL</Badge>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              <TabsContent value="reviews" className="space-y-4">
                <h2 className="text-xl font-bold">Client Reviews</h2>
                <div className="grid gap-4">
                  <Card>
                    <CardHeader>
                      <div className="flex items-center gap-4">
                        <Avatar>
                          <AvatarImage src="/placeholder-user.jpg" alt="Client" />
                          <AvatarFallback>SC</AvatarFallback>
                        </Avatar>
                        <div>
                          <CardTitle className="text-base">Sarah Chen</CardTitle>
                          <CardDescription>Tech Solutions Inc.</CardDescription>
                        </div>
                        <div className="ml-auto flex items-center">
                          <Star className="h-4 w-4 fill-primary text-primary" />
                          <Star className="h-4 w-4 fill-primary text-primary" />
                          <Star className="h-4 w-4 fill-primary text-primary" />
                          <Star className="h-4 w-4 fill-primary text-primary" />
                          <Star className="h-4 w-4 fill-primary text-primary" />
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground">
                        John delivered our web application ahead of schedule and exceeded all of our expectations. His
                        communication was excellent throughout the project, and he was quick to implement our feedback.
                        We'll definitely be working with him again!
                      </p>
                      <div className="mt-4 flex items-center text-xs text-muted-foreground">
                        <Calendar className="mr-1 h-3 w-3" />
                        March 15, 2023
                      </div>
                    </CardContent>
                  </Card>
                  <Card>
                    <CardHeader>
                      <div className="flex items-center gap-4">
                        <Avatar>
                          <AvatarImage src="/placeholder-user.jpg" alt="Client" />
                          <AvatarFallback>MJ</AvatarFallback>
                        </Avatar>
                        <div>
                          <CardTitle className="text-base">Michael Johnson</CardTitle>
                          <CardDescription>Startup Ventures</CardDescription>
                        </div>
                        <div className="ml-auto flex items-center">
                          <Star className="h-4 w-4 fill-primary text-primary" />
                          <Star className="h-4 w-4 fill-primary text-primary" />
                          <Star className="h-4 w-4 fill-primary text-primary" />
                          <Star className="h-4 w-4 fill-primary text-primary" />
                          <Star className="h-4 w-4 fill-primary text-primary" />
                        </div>
                      </div>
                    </CardHeader>
                    <CardContent>
                      <p className="text-sm text-muted-foreground">
                        Working with John was a pleasure. He took our vague idea and turned it into a beautiful,
                        functional application. His technical expertise and attention to detail made all the difference.
                        Highly recommended!
                      </p>
                      <div className="mt-4 flex items-center text-xs text-muted-foreground">
                        <Calendar className="mr-1 h-3 w-3" />
                        January 8, 2023
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </TabsContent>
              <TabsContent value="experience" className="space-y-4">
                <h2 className="text-xl font-bold">Work Experience</h2>
                <div className="space-y-6">
                  <div className="flex gap-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-md border">
                      <Briefcase className="h-6 w-6" />
                    </div>
                    <div className="space-y-1">
                      <h3 className="font-bold">Senior Developer</h3>
                      <p className="text-sm text-muted-foreground">Tech Innovations Inc.</p>
                      <p className="text-xs text-muted-foreground">Jan 2021 - Present</p>
                      <p className="mt-2 text-sm">
                        Lead developer for client projects, specializing in full-stack web applications and API
                        development. Managed a team of 3 junior developers.
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-md border">
                      <Briefcase className="h-6 w-6" />
                    </div>
                    <div className="space-y-1">
                      <h3 className="font-bold">Web Developer</h3>
                      <p className="text-sm text-muted-foreground">Digital Solutions LLC</p>
                      <p className="text-xs text-muted-foreground">Mar 2018 - Dec 2020</p>
                      <p className="mt-2 text-sm">
                        Developed and maintained client websites and web applications using React, Node.js, and MongoDB.
                        Implemented responsive designs and improved site performance.
                      </p>
                    </div>
                  </div>
                  <div className="flex gap-4">
                    <div className="flex h-12 w-12 items-center justify-center rounded-md border">
                      <Briefcase className="h-6 w-6" />
                    </div>
                    <div className="space-y-1">
                      <h3 className="font-bold">Junior Developer</h3>
                      <p className="text-sm text-muted-foreground">WebTech Studios</p>
                      <p className="text-xs text-muted-foreground">Jun 2016 - Feb 2018</p>
                      <p className="mt-2 text-sm">
                        Assisted in the development of websites and web applications. Focused on front-end development
                        with HTML, CSS, and JavaScript.
                      </p>
                    </div>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </div>
        </div>
      </main>
    </div>
  )
}

function Package2(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M3 9h18v10a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9Z" />
      <path d="m3 9 2.45-4.9A2 2 0 0 1 7.24 3h9.52a2 2 0 0 1 1.8 1.1L21 9" />
      <path d="M12 3v6" />
    </svg>
  )
}

function Github(props) {
  return (
    <svg
      {...props}
      xmlns="http://www.w3.org/2000/svg"
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M15 22v-4a4.8 4.8 0 0 0-1-3.5c3 0 6-2 6-5.5.08-1.25-.27-2.48-1-3.5.28-1.15.28-2.35 0-3.5 0 0-1 0-3 1.5-2.64-.5-5.36-.5-8 0C6 2 5 2 5 2c-.3 1.15-.3 2.35 0 3.5A5.403 5.403 0 0 0 4 9c0 3.5 3 5.5 6 5.5-.39.49-.68 1.05-.85 1.65-.17.6-.22 1.23-.15 1.85v4" />
      <path d="M9 18c-4.51 2-5-2-7-2" />
    </svg>
  )
}
