"use client"

import { useAuth } from "../../Auth"
import ClientDashboard from "@/components/ClientDashboard"
import ProviderDashboard from "@/components/ProviderDashboard"
import Header from "@/components/Header"
import { useRouter } from "next/navigation"
import { useEffect } from "react"

export default function DashboardUsuarioPage() {
  const { user, loading } = useAuth()
  const router = useRouter()

  useEffect(() => {
    if (!loading && !user) {
      router.push("/")
    }
  }, [user, loading, router])

  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>Cargando dashboard...</p>
      </div>
    )
  }

  if (!user) {
    return null
  }

  return (
    <>
      <Header />
      {user.tipo_usuario === "arrendador" ? <ClientDashboard user={user} /> : <ProviderDashboard user={user} />}
    </>
  )
}
