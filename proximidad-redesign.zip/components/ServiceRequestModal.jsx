"use client"

import { useState } from "react"
import { Modal, Form, Button, Alert, Row, Col } from "react-bootstrap"
import { FaCalendarAlt, FaDollarSign, FaFileText, FaUser } from "react-icons/fa"
import Swal from "sweetalert2"

const ServiceRequestModal = ({ show, onHide, service, user }) => {
  const [formData, setFormData] = useState({
    descripcion_personalizada: "",
    fecha_preferida: "",
    presupuesto_maximo: "",
    urgencia: "media",
    comentarios_adicionales: "",
  })
  const [loading, setLoading] = useState(false)

  const handleChange = (e) => {
    const { name, value } = e.target
    setFormData((prev) => ({
      ...prev,
      [name]: value,
    }))
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    setLoading(true)

    try {
      // Simular envío de solicitud
      await new Promise((resolve) => setTimeout(resolve, 2000))

      Swal.fire({
        title: "¡Solicitud Enviada!",
        text: "Tu solicitud ha sido enviada al proveedor. Te notificaremos cuando responda.",
        icon: "success",
        confirmButtonColor: "#005187",
      })

      onHide()
      setFormData({
        descripcion_personalizada: "",
        fecha_preferida: "",
        presupuesto_maximo: "",
        urgencia: "media",
        comentarios_adicionales: "",
      })
    } catch (error) {
      Swal.fire({
        title: "Error",
        text: "No se pudo enviar la solicitud. Inténtalo de nuevo.",
        icon: "error",
        confirmButtonColor: "#005187",
      })
    } finally {
      setLoading(false)
    }
  }

  if (!service) return null

  return (
    <Modal show={show} onHide={onHide} size="lg" centered>
      <Modal.Header closeButton>
        <Modal.Title>Solicitar Servicio</Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <div className="service-summary mb-4">
          <Row>
            <Col md={4}>
              <img src={service.imagen || "/placeholder.svg"} alt={service.nombre} className="img-fluid rounded" />
            </Col>
            <Col md={8}>
              <h5>{service.nombre}</h5>
              <p className="text-muted">{service.descripcion}</p>
              <div className="service-details">
                <div className="detail-item">
                  <FaUser className="me-2" />
                  <strong>Proveedor:</strong> {service.proveedor.nombre}
                </div>
                <div className="detail-item">
                  <FaDollarSign className="me-2" />
                  <strong>Precio base:</strong> ${service.precio.toLocaleString()}
                </div>
                <div className="detail-item">
                  <FaCalendarAlt className="me-2" />
                  <strong>Tiempo de entrega:</strong> {service.tiempo_entrega}
                </div>
              </div>
            </Col>
          </Row>
        </div>

        <Alert variant="info">
          <strong>Información importante:</strong> Esta solicitud será enviada directamente al proveedor. Te
          notificaremos cuando responda a tu solicitud.
        </Alert>

        <Form onSubmit={handleSubmit}>
          <Row>
            <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label>
                  <FaFileText className="me-2" />
                  Descripción del proyecto *
                </Form.Label>
                <Form.Control
                  as="textarea"
                  rows={4}
                  name="descripcion_personalizada"
                  value={formData.descripcion_personalizada}
                  onChange={handleChange}
                  placeholder="Describe detalladamente lo que necesitas..."
                  required
                />
              </Form.Group>
            </Col>
            <Col md={6}>
              <Form.Group className="mb-3">
                <Form.Label>
                  <FaCalendarAlt className="me-2" />
                  Fecha preferida de inicio
                </Form.Label>
                <Form.Control
                  type="date"
                  name="fecha_preferida"
                  value={formData.fecha_preferida}
                  onChange={handleChange}
                  min={new Date().toISOString().split("T")[0]}
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>
                  <FaDollarSign className="me-2" />
                  Presupuesto máximo
                </Form.Label>
                <Form.Control
                  type="number"
                  name="presupuesto_maximo"
                  value={formData.presupuesto_maximo}
                  onChange={handleChange}
                  placeholder="Opcional"
                  min="0"
                />
              </Form.Group>

              <Form.Group className="mb-3">
                <Form.Label>Urgencia del proyecto</Form.Label>
                <Form.Select name="urgencia" value={formData.urgencia} onChange={handleChange}>
                  <option value="baja">Baja - Tengo tiempo flexible</option>
                  <option value="media">Media - Fecha estándar</option>
                  <option value="alta">Alta - Lo necesito pronto</option>
                </Form.Select>
              </Form.Group>
            </Col>
          </Row>

          <Form.Group className="mb-3">
            <Form.Label>Comentarios adicionales</Form.Label>
            <Form.Control
              as="textarea"
              rows={3}
              name="comentarios_adicionales"
              value={formData.comentarios_adicionales}
              onChange={handleChange}
              placeholder="Cualquier información adicional que consideres importante..."
            />
          </Form.Group>
        </Form>
      </Modal.Body>

      <Modal.Footer>
        <Button variant="secondary" onClick={onHide} disabled={loading}>
          Cancelar
        </Button>
        <Button
          variant="primary"
          onClick={handleSubmit}
          disabled={loading || !formData.descripcion_personalizada.trim()}
        >
          {loading ? "Enviando..." : "Enviar Solicitud"}
        </Button>
      </Modal.Footer>
    </Modal>
  )
}

export default ServiceRequestModal
