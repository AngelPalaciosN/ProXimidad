"use client"

import { useState, useEffect } from "react"
import { Container, Row, Col, Card, Button, Badge, Table } from "react-bootstrap"
import {
  FaPlus,
  FaEdit,
  FaTrash,
  FaEye,
  FaStar,
  FaClock,
  FaCheckCircle,
  FaTimesCircle,
  FaSpinner,
  FaDollarSign,
  FaChartLine,
  FaUsers,
  FaBriefcase,
} from "react-icons/fa"
import ServiceManagementModal from "./ServiceManagementModal"
import RequestDetailsModal from "./RequestDetailsModal"
import "../../scss/component-styles/ProviderDashboard.scss"

const ProviderDashboard = ({ user }) => {
  const [activeTab, setActiveTab] = useState("overview")
  const [myServices, setMyServices] = useState([])
  const [serviceRequests, setServiceRequests] = useState([])
  const [showServiceModal, setShowServiceModal] = useState(false)
  const [showRequestModal, setShowRequestModal] = useState(false)
  const [selectedService, setSelectedService] = useState(null)
  const [selectedRequest, setSelectedRequest] = useState(null)
  const [loading, setLoading] = useState(true)
  const [stats, setStats] = useState({})

  // Mock data - En producción vendría de la API
  const mockServices = [
    {
      id: 1,
      nombre: "Desarrollo Web Profesional",
      descripcion: "Creación de sitios web modernos y responsivos",
      precio: 1500,
      categoria: "Tecnología",
      activo: true,
      fecha_creacion: "2024-01-01",
      solicitudes_recibidas: 5,
      imagen: "/placeholder.svg?height=200&width=300",
    },
    {
      id: 2,
      nombre: "Consultoría de Negocios",
      descripcion: "Asesoría estratégica para empresas",
      precio: 2000,
      categoria: "Negocios",
      activo: true,
      fecha_creacion: "2024-01-15",
      solicitudes_recibidas: 3,
      imagen: "/placeholder.svg?height=200&width=300",
    },
  ]

  const mockRequests = [
    {
      id: 1,
      servicio: "Desarrollo Web Profesional",
      cliente: {
        nombre: "Ana Martínez",
        avatar: "https://randomuser.me/api/portraits/women/4.jpg",
        email: "ana@ejemplo.com",
      },
      fecha_solicitud: "2024-01-20",
      estado: "pendiente",
      precio_propuesto: 1500,
      descripcion: "Necesito un sitio web para mi negocio de repostería con carrito de compras",
      urgencia: "media",
    },
    {
      id: 2,
      servicio: "Consultoría de Negocios",
      cliente: {
        nombre: "Roberto Sánchez",
        avatar: "https://randomuser.me/api/portraits/men/5.jpg",
        email: "roberto@ejemplo.com",
      },
      fecha_solicitud: "2024-01-18",
      estado: "aceptado",
      precio_propuesto: 2000,
      descripcion: "Necesito ayuda para expandir mi negocio a nuevos mercados",
      urgencia: "alta",
    },
    {
      id: 3,
      servicio: "Desarrollo Web Profesional",
      cliente: {
        nombre: "Laura Jiménez",
        avatar: "https://randomuser.me/api/portraits/women/6.jpg",
        email: "laura@ejemplo.com",
      },
      fecha_solicitud: "2024-01-15",
      estado: "completado",
      precio_propuesto: 1500,
      descripcion: "Sitio web corporativo para empresa de tecnología",
      urgencia: "baja",
    },
  ]

  const mockStats = {
    servicios_activos: 2,
    solicitudes_pendientes: 1,
    proyectos_completados: 8,
    ingresos_mes: 4500,
    calificacion_promedio: 4.8,
    clientes_satisfechos: 15,
  }

  useEffect(() => {
    // Simular carga de datos
    setTimeout(() => {
      setMyServices(mockServices)
      setServiceRequests(mockRequests)
      setStats(mockStats)
      setLoading(false)
    }, 1000)
  }, [])

  const handleEditService = (service) => {
    setSelectedService(service)
    setShowServiceModal(true)
  }

  const handleCreateService = () => {
    setSelectedService(null)
    setShowServiceModal(true)
  }

  const handleViewRequest = (request) => {
    setSelectedRequest(request)
    setShowRequestModal(true)
  }

  const handleRequestAction = (requestId, action) => {
    setServiceRequests((prev) =>
      prev.map((request) => (request.id === requestId ? { ...request, estado: action } : request)),
    )
  }

  const getStatusBadge = (status) => {
    const statusConfig = {
      pendiente: { variant: "warning", icon: FaClock, text: "Pendiente" },
      aceptado: { variant: "info", icon: FaSpinner, text: "En Proceso" },
      completado: { variant: "success", icon: FaCheckCircle, text: "Completado" },
      rechazado: { variant: "danger", icon: FaTimesCircle, text: "Rechazado" },
    }

    const config = statusConfig[status] || statusConfig.pendiente
    const IconComponent = config.icon

    return (
      <Badge bg={config.variant} className="d-flex align-items-center gap-1">
        <IconComponent size={12} />
        {config.text}
      </Badge>
    )
  }

  const getUrgencyBadge = (urgency) => {
    const urgencyConfig = {
      alta: { variant: "danger", text: "Alta" },
      media: { variant: "warning", text: "Media" },
      baja: { variant: "success", text: "Baja" },
    }

    const config = urgencyConfig[urgency] || urgencyConfig.media

    return (
      <Badge bg={config.variant} size="sm">
        {config.text}
      </Badge>
    )
  }

  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>Cargando dashboard...</p>
      </div>
    )
  }

  return (
    <div className="provider-dashboard">
      <Container fluid>
        <div className="dashboard-header">
          <Row>
            <Col>
              <h1>Panel de Proveedor</h1>
              <p>Gestiona tus servicios y solicitudes de clientes</p>
            </Col>
          </Row>
        </div>

        <div className="dashboard-tabs">
          <Button
            variant={activeTab === "overview" ? "primary" : "outline-primary"}
            onClick={() => setActiveTab("overview")}
            className="tab-button"
          >
            <FaChartLine className="me-2" />
            Resumen
          </Button>
          <Button
            variant={activeTab === "services" ? "primary" : "outline-primary"}
            onClick={() => setActiveTab("services")}
            className="tab-button"
          >
            <FaBriefcase className="me-2" />
            Mis Servicios
            <Badge bg="light" text="dark" className="ms-2">
              {myServices.length}
            </Badge>
          </Button>
          <Button
            variant={activeTab === "requests" ? "primary" : "outline-primary"}
            onClick={() => setActiveTab("requests")}
            className="tab-button"
          >
            <FaUsers className="me-2" />
            Solicitudes
            {serviceRequests.filter((r) => r.estado === "pendiente").length > 0 && (
              <Badge bg="danger" className="ms-2">
                {serviceRequests.filter((r) => r.estado === "pendiente").length}
              </Badge>
            )}
          </Button>
        </div>

        <div className="dashboard-content">
          {activeTab === "overview" && (
            <div className="overview">
              <Row className="mb-4">
                <Col lg={3} md={6} className="mb-3">
                  <Card className="stats-card">
                    <Card.Body>
                      <div className="stats-icon">
                        <FaBriefcase />
                      </div>
                      <div className="stats-content">
                        <h3>{stats.servicios_activos}</h3>
                        <p>Servicios Activos</p>
                      </div>
                    </Card.Body>
                  </Card>
                </Col>
                <Col lg={3} md={6} className="mb-3">
                  <Card className="stats-card">
                    <Card.Body>
                      <div className="stats-icon">
                        <FaClock />
                      </div>
                      <div className="stats-content">
                        <h3>{stats.solicitudes_pendientes}</h3>
                        <p>Solicitudes Pendientes</p>
                      </div>
                    </Card.Body>
                  </Card>
                </Col>
                <Col lg={3} md={6} className="mb-3">
                  <Card className="stats-card">
                    <Card.Body>
                      <div className="stats-icon">
                        <FaCheckCircle />
                      </div>
                      <div className="stats-content">
                        <h3>{stats.proyectos_completados}</h3>
                        <p>Proyectos Completados</p>
                      </div>
                    </Card.Body>
                  </Card>
                </Col>
                <Col lg={3} md={6} className="mb-3">
                  <Card className="stats-card">
                    <Card.Body>
                      <div className="stats-icon">
                        <FaDollarSign />
                      </div>
                      <div className="stats-content">
                        <h3>${stats.ingresos_mes.toLocaleString()}</h3>
                        <p>Ingresos del Mes</p>
                      </div>
                    </Card.Body>
                  </Card>
                </Col>
              </Row>

              <Row>
                <Col lg={8}>
                  <Card className="recent-requests">
                    <Card.Header>
                      <h5>Solicitudes Recientes</h5>
                    </Card.Header>
                    <Card.Body>
                      {serviceRequests.slice(0, 3).map((request) => (
                        <div key={request.id} className="request-item">
                          <div className="request-info">
                            <div className="client-avatar">
                              <img src={request.cliente.avatar || "/placeholder.svg"} alt={request.cliente.nombre} />
                            </div>
                            <div className="request-details">
                              <h6>{request.cliente.nombre}</h6>
                              <p>{request.servicio}</p>
                              <small>{new Date(request.fecha_solicitud).toLocaleDateString()}</small>
                            </div>
                          </div>
                          <div className="request-status">
                            {getStatusBadge(request.estado)}
                            {getUrgencyBadge(request.urgencia)}
                          </div>
                        </div>
                      ))}
                    </Card.Body>
                  </Card>
                </Col>
                <Col lg={4}>
                  <Card className="performance-card">
                    <Card.Header>
                      <h5>Rendimiento</h5>
                    </Card.Header>
                    <Card.Body>
                      <div className="performance-item">
                        <div className="performance-label">
                          <FaStar className="me-2" />
                          Calificación Promedio
                        </div>
                        <div className="performance-value">{stats.calificacion_promedio}/5.0</div>
                      </div>
                      <div className="performance-item">
                        <div className="performance-label">
                          <FaUsers className="me-2" />
                          Clientes Satisfechos
                        </div>
                        <div className="performance-value">{stats.clientes_satisfechos}</div>
                      </div>
                    </Card.Body>
                  </Card>
                </Col>
              </Row>
            </div>
          )}

          {activeTab === "services" && (
            <div className="my-services">
              <div className="services-header">
                <h3>Mis Servicios</h3>
                <Button variant="primary" onClick={handleCreateService}>
                  <FaPlus className="me-2" />
                  Crear Nuevo Servicio
                </Button>
              </div>

              <Row>
                {myServices.map((service) => (
                  <Col key={service.id} lg={4} md={6} className="mb-4">
                    <Card className="service-card">
                      <Card.Img variant="top" src={service.imagen} />
                      <Card.Body>
                        <div className="service-header">
                          <Card.Title>{service.nombre}</Card.Title>
                          <Badge bg={service.activo ? "success" : "secondary"}>
                            {service.activo ? "Activo" : "Inactivo"}
                          </Badge>
                        </div>

                        <Card.Text>{service.descripcion}</Card.Text>

                        <div className="service-stats">
                          <div className="stat">
                            <strong>${service.precio.toLocaleString()}</strong>
                            <small>Precio</small>
                          </div>
                          <div className="stat">
                            <strong>{service.solicitudes_recibidas}</strong>
                            <small>Solicitudes</small>
                          </div>
                        </div>

                        <div className="service-actions">
                          <Button variant="outline-primary" size="sm" onClick={() => handleEditService(service)}>
                            <FaEdit className="me-1" />
                            Editar
                          </Button>
                          <Button variant="outline-secondary" size="sm">
                            <FaEye className="me-1" />
                            Ver
                          </Button>
                          <Button variant="outline-danger" size="sm">
                            <FaTrash className="me-1" />
                            Eliminar
                          </Button>
                        </div>
                      </Card.Body>
                    </Card>
                  </Col>
                ))}
              </Row>
            </div>
          )}

          {activeTab === "requests" && (
            <div className="service-requests">
              <h3 className="mb-4">Solicitudes de Servicios</h3>

              <Card>
                <Card.Body>
                  <Table responsive hover>
                    <thead>
                      <tr>
                        <th>Cliente</th>
                        <th>Servicio</th>
                        <th>Fecha</th>
                        <th>Estado</th>
                        <th>Urgencia</th>
                        <th>Precio</th>
                        <th>Acciones</th>
                      </tr>
                    </thead>
                    <tbody>
                      {serviceRequests.map((request) => (
                        <tr key={request.id}>
                          <td>
                            <div className="client-info">
                              <img
                                src={request.cliente.avatar || "/placeholder.svg"}
                                alt={request.cliente.nombre}
                                className="client-avatar-small"
                              />
                              <div>
                                <div className="client-name">{request.cliente.nombre}</div>
                                <small className="client-email">{request.cliente.email}</small>
                              </div>
                            </div>
                          </td>
                          <td>{request.servicio}</td>
                          <td>{new Date(request.fecha_solicitud).toLocaleDateString()}</td>
                          <td>{getStatusBadge(request.estado)}</td>
                          <td>{getUrgencyBadge(request.urgencia)}</td>
                          <td>${request.precio_propuesto.toLocaleString()}</td>
                          <td>
                            <div className="action-buttons">
                              <Button variant="outline-primary" size="sm" onClick={() => handleViewRequest(request)}>
                                <FaEye />
                              </Button>
                              {request.estado === "pendiente" && (
                                <>
                                  <Button
                                    variant="outline-success"
                                    size="sm"
                                    onClick={() => handleRequestAction(request.id, "aceptado")}
                                  >
                                    <FaCheckCircle />
                                  </Button>
                                  <Button
                                    variant="outline-danger"
                                    size="sm"
                                    onClick={() => handleRequestAction(request.id, "rechazado")}
                                  >
                                    <FaTimesCircle />
                                  </Button>
                                </>
                              )}
                            </div>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </Table>
                </Card.Body>
              </Card>
            </div>
          )}
        </div>
      </Container>

      <ServiceManagementModal
        show={showServiceModal}
        onHide={() => setShowServiceModal(false)}
        service={selectedService}
        user={user}
      />

      <RequestDetailsModal
        show={showRequestModal}
        onHide={() => setShowRequestModal(false)}
        request={selectedRequest}
        onAction={handleRequestAction}
      />
    </div>
  )
}

export default ProviderDashboard
