"use client"

import { useState } from "react"
import { Modal, Button, Row, Col, Badge, Form, Alert } from "react-bootstrap"
import {
  FaUser,
  FaEnvelope,
  FaCalendarAlt,
  FaDollarSign,
  FaFileText,
  FaCheckCircle,
  FaTimesCircle,
  FaReply,
} from "react-icons/fa"
import Swal from "sweetalert2"

const RequestDetailsModal = ({ show, onHide, request, onAction }) => {
  const [response, setResponse] = useState("")
  const [counterOffer, setCounterOffer] = useState("")
  const [loading, setLoading] = useState(false)

  const handleAction = async (action) => {
    setLoading(true)

    try {
      await new Promise((resolve) => setTimeout(resolve, 1500))

      const actionMessages = {
        aceptado: "Solicitud aceptada correctamente. El cliente será notificado.",
        rechazado: "Solicitud rechazada. El cliente será notificado.",
        completado: "Proyecto marcado como completado.",
      }

      Swal.fire({
        title: "¡Acción completada!",
        text: actionMessages[action],
        icon: "success",
        confirmButtonColor: "#005187",
      })

      onAction(request.id, action)
      onHide()
    } catch (error) {
      Swal.fire({
        title: "Error",
        text: "No se pudo completar la acción. Inténtalo de nuevo.",
        icon: "error",
        confirmButtonColor: "#005187",
      })
    } finally {
      setLoading(false)
    }
  }

  const handleSendResponse = async () => {
    if (!response.trim()) return

    setLoading(true)

    try {
      await new Promise((resolve) => setTimeout(resolve, 1500))

      Swal.fire({
        title: "¡Respuesta enviada!",
        text: "Tu respuesta ha sido enviada al cliente.",
        icon: "success",
        confirmButtonColor: "#005187",
      })

      setResponse("")
      setCounterOffer("")
    } catch (error) {
      Swal.fire({
        title: "Error",
        text: "No se pudo enviar la respuesta. Inténtalo de nuevo.",
        icon: "error",
        confirmButtonColor: "#005187",
      })
    } finally {
      setLoading(false)
    }
  }

  const getStatusBadge = (status) => {
    const statusConfig = {
      pendiente: { variant: "warning", text: "Pendiente" },
      aceptado: { variant: "info", text: "En Proceso" },
      completado: { variant: "success", text: "Completado" },
      rechazado: { variant: "danger", text: "Rechazado" },
    }

    const config = statusConfig[status] || statusConfig.pendiente

    return <Badge bg={config.variant}>{config.text}</Badge>
  }

  const getUrgencyBadge = (urgency) => {
    const urgencyConfig = {
      alta: { variant: "danger", text: "Alta" },
      media: { variant: "warning", text: "Media" },
      baja: { variant: "success", text: "Baja" },
    }

    const config = urgencyConfig[urgency] || urgencyConfig.media

    return <Badge bg={config.variant}>{config.text}</Badge>
  }

  if (!request) return null

  return (
    <Modal show={show} onHide={onHide} size="lg" centered>
      <Modal.Header closeButton>
        <Modal.Title>Detalles de la Solicitud</Modal.Title>
      </Modal.Header>

      <Modal.Body>
        <Row className="mb-4">
          <Col md={8}>
            <div className="request-header">
              <h5>{request.servicio}</h5>
              <div className="request-badges">
                {getStatusBadge(request.estado)}
                {getUrgencyBadge(request.urgencia)}
              </div>
            </div>
          </Col>
          <Col md={4} className="text-end">
            <div className="request-price">
              <FaDollarSign className="me-1" />
              <strong>${request.precio_propuesto.toLocaleString()}</strong>
            </div>
            <small className="text-muted">
              <FaCalendarAlt className="me-1" />
              {new Date(request.fecha_solicitud).toLocaleDateString()}
            </small>
          </Col>
        </Row>

        <Row className="mb-4">
          <Col md={6}>
            <div className="client-info">
              <h6>Información del Cliente</h6>
              <div className="client-details">
                <div className="client-avatar-large">
                  <img src={request.cliente.avatar || "/placeholder.svg"} alt={request.cliente.nombre} />
                </div>
                <div className="client-data">
                  <div className="detail-item">
                    <FaUser className="me-2" />
                    <strong>{request.cliente.nombre}</strong>
                  </div>
                  <div className="detail-item">
                    <FaEnvelope className="me-2" />
                    {request.cliente.email}
                  </div>
                </div>
              </div>
            </div>
          </Col>
          <Col md={6}>
            <div className="request-summary">
              <h6>Resumen de la Solicitud</h6>
              <div className="summary-items">
                <div className="summary-item">
                  <strong>Servicio:</strong> {request.servicio}
                </div>
                <div className="summary-item">
                  <strong>Precio propuesto:</strong> ${request.precio_propuesto.toLocaleString()}
                </div>
                <div className="summary-item">
                  <strong>Urgencia:</strong> {request.urgencia}
                </div>
                <div className="summary-item">
                  <strong>Estado:</strong> {request.estado}
                </div>
              </div>
            </div>
          </Col>
        </Row>

        <div className="request-description mb-4">
          <h6>
            <FaFileText className="me-2" />
            Descripción del Proyecto
          </h6>
          <div className="description-content">
            <p>{request.descripcion}</p>
          </div>
        </div>

        {request.estado === "pendiente" && (
          <div className="response-section">
            <h6>
              <FaReply className="me-2" />
              Responder al Cliente
            </h6>

            <Form.Group className="mb-3">
              <Form.Label>Mensaje de respuesta</Form.Label>
              <Form.Control
                as="textarea"
                rows={4}
                value={response}
                onChange={(e) => setResponse(e.target.value)}
                placeholder="Escribe tu respuesta al cliente..."
              />
            </Form.Group>

            <Form.Group className="mb-3">
              <Form.Label>Contraoferta de precio (opcional)</Form.Label>
              <Form.Control
                type="number"
                value={counterOffer}
                onChange={(e) => setCounterOffer(e.target.value)}
                placeholder="Nuevo precio propuesto"
                min="0"
              />
            </Form.Group>

            <div className="response-actions mb-3">
              <Button
                variant="outline-primary"
                onClick={handleSendResponse}
                disabled={loading || !response.trim()}
                className="me-2"
              >
                Enviar Respuesta
              </Button>
            </div>
          </div>
        )}

        {request.estado === "aceptado" && (
          <Alert variant="info">
            <strong>Proyecto en proceso:</strong> Este proyecto está actualmente en desarrollo. Puedes marcarlo como
            completado cuando hayas terminado el trabajo.
          </Alert>
        )}

        {request.estado === "completado" && (
          <Alert variant="success">
            <strong>Proyecto completado:</strong> Este proyecto ha sido marcado como completado exitosamente.
          </Alert>
        )}

        {request.estado === "rechazado" && (
          <Alert variant="danger">
            <strong>Solicitud rechazada:</strong> Esta solicitud fue rechazada anteriormente.
          </Alert>
        )}
      </Modal.Body>

      <Modal.Footer>
        <Button variant="secondary" onClick={onHide} disabled={loading}>
          Cerrar
        </Button>

        {request.estado === "pendiente" && (
          <>
            <Button variant="success" onClick={() => handleAction("aceptado")} disabled={loading} className="me-2">
              <FaCheckCircle className="me-1" />
              Aceptar Solicitud
            </Button>
            <Button variant="danger" onClick={() => handleAction("rechazado")} disabled={loading}>
              <FaTimesCircle className="me-1" />
              Rechazar
            </Button>
          </>
        )}

        {request.estado === "aceptado" && (
          <Button variant="success" onClick={() => handleAction("completado")} disabled={loading}>
            <FaCheckCircle className="me-1" />
            Marcar como Completado
          </Button>
        )}
      </Modal.Footer>
    </Modal>
  )
}

export default RequestDetailsModal
