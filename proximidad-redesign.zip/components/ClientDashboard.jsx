"use client"

import { useState, useEffect } from "react"
import { Container, Row, Col, Card, Button, Badge, Form } from "react-bootstrap"
import {
  FaSearch,
  FaHeart,
  FaShoppingCart,
  FaEye,
  FaStar,
  FaMapMarkerAlt,
  FaClock,
  FaCheckCircle,
  FaTimesCircle,
  FaSpinner,
} from "react-icons/fa"
import ServiceRequestModal from "./ServiceRequestModal"
import "../../scss/component-styles/ClientDashboard.scss"

const ClientDashboard = ({ user }) => {
  const [activeTab, setActiveTab] = useState("browse")
  const [services, setServices] = useState([])
  const [myRequests, setMyRequests] = useState([])
  const [favorites, setFavorites] = useState([])
  const [searchTerm, setSearchTerm] = useState("")
  const [selectedCategory, setSelectedCategory] = useState("")
  const [showRequestModal, setShowRequestModal] = useState(false)
  const [selectedService, setSelectedService] = useState(null)
  const [loading, setLoading] = useState(true)

  // Mock data - En producción vendría de la API
  const mockServices = [
    {
      id: 1,
      nombre: "Desarrollo Web Profesional",
      descripcion: "Creación de sitios web modernos y responsivos con las últimas tecnologías",
      precio: 1500,
      categoria: "Tecnología",
      proveedor: {
        nombre: "Juan Pérez",
        avatar: "https://randomuser.me/api/portraits/men/1.jpg",
        calificacion: 4.8,
        ubicacion: "San José, Costa Rica",
      },
      imagen: "/placeholder.svg?height=200&width=300",
      tiempo_entrega: "2-3 semanas",
      disponible: true,
    },
    {
      id: 2,
      nombre: "Diseño Gráfico Creativo",
      descripcion: "Diseño de logos, banners y material publicitario profesional",
      precio: 800,
      categoria: "Diseño",
      proveedor: {
        nombre: "María González",
        avatar: "https://randomuser.me/api/portraits/women/2.jpg",
        calificacion: 4.9,
        ubicacion: "Heredia, Costa Rica",
      },
      imagen: "/placeholder.svg?height=200&width=300",
      tiempo_entrega: "1 semana",
      disponible: true,
    },
    {
      id: 3,
      nombre: "Marketing Digital Integral",
      descripcion: "Estrategias completas de marketing digital y gestión de redes sociales",
      precio: 1200,
      categoria: "Marketing",
      proveedor: {
        nombre: "Carlos Rodríguez",
        avatar: "https://randomuser.me/api/portraits/men/3.jpg",
        calificacion: 4.7,
        ubicacion: "Alajuela, Costa Rica",
      },
      imagen: "/placeholder.svg?height=200&width=300",
      tiempo_entrega: "1-2 semanas",
      disponible: true,
    },
  ]

  const mockRequests = [
    {
      id: 1,
      servicio: "Desarrollo Web Profesional",
      proveedor: "Juan Pérez",
      fecha_solicitud: "2024-01-15",
      estado: "pendiente",
      precio_acordado: 1500,
      descripcion_personalizada: "Necesito un sitio web para mi negocio de repostería",
    },
    {
      id: 2,
      servicio: "Diseño Gráfico Creativo",
      proveedor: "María González",
      fecha_solicitud: "2024-01-10",
      estado: "aceptado",
      precio_acordado: 800,
      descripcion_personalizada: "Logo para empresa de tecnología",
    },
    {
      id: 3,
      servicio: "Marketing Digital Integral",
      proveedor: "Carlos Rodríguez",
      fecha_solicitud: "2024-01-05",
      estado: "completado",
      precio_acordado: 1200,
      descripcion_personalizada: "Campaña para lanzamiento de producto",
    },
  ]

  useEffect(() => {
    // Simular carga de datos
    setTimeout(() => {
      setServices(mockServices)
      setMyRequests(mockRequests)
      setFavorites([1, 3])
      setLoading(false)
    }, 1000)
  }, [])

  const filteredServices = services.filter((service) => {
    const matchesSearch =
      service.nombre.toLowerCase().includes(searchTerm.toLowerCase()) ||
      service.descripcion.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesCategory = selectedCategory === "" || service.categoria === selectedCategory
    return matchesSearch && matchesCategory
  })

  const handleRequestService = (service) => {
    setSelectedService(service)
    setShowRequestModal(true)
  }

  const handleToggleFavorite = (serviceId) => {
    setFavorites((prev) => (prev.includes(serviceId) ? prev.filter((id) => id !== serviceId) : [...prev, serviceId]))
  }

  const getStatusBadge = (status) => {
    const statusConfig = {
      pendiente: { variant: "warning", icon: FaClock, text: "Pendiente" },
      aceptado: { variant: "info", icon: FaSpinner, text: "En Proceso" },
      completado: { variant: "success", icon: FaCheckCircle, text: "Completado" },
      rechazado: { variant: "danger", icon: FaTimesCircle, text: "Rechazado" },
    }

    const config = statusConfig[status] || statusConfig.pendiente
    const IconComponent = config.icon

    return (
      <Badge bg={config.variant} className="d-flex align-items-center gap-1">
        <IconComponent size={12} />
        {config.text}
      </Badge>
    )
  }

  if (loading) {
    return (
      <div className="loading-container">
        <div className="loading-spinner"></div>
        <p>Cargando dashboard...</p>
      </div>
    )
  }

  return (
    <div className="client-dashboard">
      <Container fluid>
        <div className="dashboard-header">
          <Row>
            <Col>
              <h1>¡Bienvenido, {user.nombre_completo}!</h1>
              <p>Encuentra y solicita los servicios que necesitas</p>
            </Col>
          </Row>
        </div>

        <div className="dashboard-tabs">
          <Button
            variant={activeTab === "browse" ? "primary" : "outline-primary"}
            onClick={() => setActiveTab("browse")}
            className="tab-button"
          >
            <FaSearch className="me-2" />
            Explorar Servicios
          </Button>
          <Button
            variant={activeTab === "requests" ? "primary" : "outline-primary"}
            onClick={() => setActiveTab("requests")}
            className="tab-button"
          >
            <FaShoppingCart className="me-2" />
            Mis Solicitudes
            {myRequests.length > 0 && (
              <Badge bg="light" text="dark" className="ms-2">
                {myRequests.length}
              </Badge>
            )}
          </Button>
          <Button
            variant={activeTab === "favorites" ? "primary" : "outline-primary"}
            onClick={() => setActiveTab("favorites")}
            className="tab-button"
          >
            <FaHeart className="me-2" />
            Favoritos
            {favorites.length > 0 && (
              <Badge bg="light" text="dark" className="ms-2">
                {favorites.length}
              </Badge>
            )}
          </Button>
        </div>

        <div className="dashboard-content">
          {activeTab === "browse" && (
            <div className="browse-services">
              <div className="search-filters">
                <Row className="mb-4">
                  <Col md={8}>
                    <div className="search-box">
                      <FaSearch className="search-icon" />
                      <Form.Control
                        type="text"
                        placeholder="Buscar servicios..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="search-input"
                      />
                    </div>
                  </Col>
                  <Col md={4}>
                    <Form.Select
                      value={selectedCategory}
                      onChange={(e) => setSelectedCategory(e.target.value)}
                      className="category-filter"
                    >
                      <option value="">Todas las categorías</option>
                      <option value="Tecnología">Tecnología</option>
                      <option value="Diseño">Diseño</option>
                      <option value="Marketing">Marketing</option>
                    </Form.Select>
                  </Col>
                </Row>
              </div>

              <Row>
                {filteredServices.map((service) => (
                  <Col key={service.id} lg={4} md={6} className="mb-4">
                    <Card className="service-card h-100">
                      <div className="service-image">
                        <Card.Img variant="top" src={service.imagen} />
                        <Button
                          variant="link"
                          className="favorite-btn"
                          onClick={() => handleToggleFavorite(service.id)}
                        >
                          <FaHeart className={favorites.includes(service.id) ? "favorited" : ""} />
                        </Button>
                      </div>

                      <Card.Body className="d-flex flex-column">
                        <div className="service-header">
                          <Card.Title>{service.nombre}</Card.Title>
                          <Badge bg="secondary" className="category-badge">
                            {service.categoria}
                          </Badge>
                        </div>

                        <Card.Text className="service-description">{service.descripcion}</Card.Text>

                        <div className="provider-info">
                          <div className="provider-avatar">
                            <img src={service.proveedor.avatar || "/placeholder.svg"} alt={service.proveedor.nombre} />
                          </div>
                          <div className="provider-details">
                            <h6>{service.proveedor.nombre}</h6>
                            <div className="provider-meta">
                              <div className="rating">
                                <FaStar className="star-icon" />
                                <span>{service.proveedor.calificacion}</span>
                              </div>
                              <div className="location">
                                <FaMapMarkerAlt className="location-icon" />
                                <span>{service.proveedor.ubicacion}</span>
                              </div>
                            </div>
                          </div>
                        </div>

                        <div className="service-footer mt-auto">
                          <div className="service-meta">
                            <div className="price">
                              <strong>${service.precio.toLocaleString()}</strong>
                            </div>
                            <div className="delivery-time">
                              <FaClock className="me-1" />
                              {service.tiempo_entrega}
                            </div>
                          </div>

                          <div className="service-actions">
                            <Button variant="outline-primary" size="sm" className="me-2">
                              <FaEye className="me-1" />
                              Ver Detalles
                            </Button>
                            <Button
                              variant="primary"
                              size="sm"
                              onClick={() => handleRequestService(service)}
                              disabled={!service.disponible}
                            >
                              Solicitar
                            </Button>
                          </div>
                        </div>
                      </Card.Body>
                    </Card>
                  </Col>
                ))}
              </Row>
            </div>
          )}

          {activeTab === "requests" && (
            <div className="my-requests">
              <h3 className="mb-4">Mis Solicitudes de Servicios</h3>
              {myRequests.length === 0 ? (
                <div className="empty-state">
                  <FaShoppingCart size={48} className="empty-icon" />
                  <h4>No tienes solicitudes aún</h4>
                  <p>Explora nuestros servicios y realiza tu primera solicitud</p>
                  <Button variant="primary" onClick={() => setActiveTab("browse")}>
                    Explorar Servicios
                  </Button>
                </div>
              ) : (
                <Row>
                  {myRequests.map((request) => (
                    <Col key={request.id} lg={6} className="mb-4">
                      <Card className="request-card">
                        <Card.Body>
                          <div className="request-header">
                            <h5>{request.servicio}</h5>
                            {getStatusBadge(request.estado)}
                          </div>

                          <div className="request-details">
                            <p>
                              <strong>Proveedor:</strong> {request.proveedor}
                            </p>
                            <p>
                              <strong>Precio acordado:</strong> ${request.precio_acordado.toLocaleString()}
                            </p>
                            <p>
                              <strong>Fecha de solicitud:</strong>{" "}
                              {new Date(request.fecha_solicitud).toLocaleDateString()}
                            </p>
                            <p>
                              <strong>Descripción:</strong> {request.descripcion_personalizada}
                            </p>
                          </div>

                          <div className="request-actions">
                            <Button variant="outline-primary" size="sm" className="me-2">
                              Ver Detalles
                            </Button>
                            {request.estado === "pendiente" && (
                              <Button variant="outline-danger" size="sm">
                                Cancelar
                              </Button>
                            )}
                          </div>
                        </Card.Body>
                      </Card>
                    </Col>
                  ))}
                </Row>
              )}
            </div>
          )}

          {activeTab === "favorites" && (
            <div className="favorites">
              <h3 className="mb-4">Servicios Favoritos</h3>
              {favorites.length === 0 ? (
                <div className="empty-state">
                  <FaHeart size={48} className="empty-icon" />
                  <h4>No tienes favoritos aún</h4>
                  <p>Marca servicios como favoritos para encontrarlos fácilmente</p>
                  <Button variant="primary" onClick={() => setActiveTab("browse")}>
                    Explorar Servicios
                  </Button>
                </div>
              ) : (
                <Row>
                  {services
                    .filter((service) => favorites.includes(service.id))
                    .map((service) => (
                      <Col key={service.id} lg={4} md={6} className="mb-4">
                        <Card className="service-card h-100">
                          <div className="service-image">
                            <Card.Img variant="top" src={service.imagen} />
                            <Button
                              variant="link"
                              className="favorite-btn"
                              onClick={() => handleToggleFavorite(service.id)}
                            >
                              <FaHeart className="favorited" />
                            </Button>
                          </div>

                          <Card.Body className="d-flex flex-column">
                            <Card.Title>{service.nombre}</Card.Title>
                            <Card.Text>{service.descripcion}</Card.Text>

                            <div className="service-footer mt-auto">
                              <div className="price">
                                <strong>${service.precio.toLocaleString()}</strong>
                              </div>
                              <Button variant="primary" size="sm" onClick={() => handleRequestService(service)}>
                                Solicitar
                              </Button>
                            </div>
                          </Card.Body>
                        </Card>
                      </Col>
                    ))}
                </Row>
              )}
            </div>
          )}
        </div>
      </Container>

      <ServiceRequestModal
        show={showRequestModal}
        onHide={() => setShowRequestModal(false)}
        service={selectedService}
        user={user}
      />
    </div>
  )
}

export default ClientDashboard
