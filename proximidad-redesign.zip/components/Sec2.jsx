"use client"

import "../../styles/components/_sec2.scss"
import { useState, useEffect } from "react"
import { Container, Row, Col, Carousel, Card } from "react-bootstrap"
import { CheckCircle, Clock, Shield } from "lucide-react"
import Image from "next/image"

export default function Sec2() {
  const xAnimations = [
    {
      symbol: "X",
      color: "#005187",
      style: { transform: "rotate(0deg)", transition: "transform 0.3s ease-in-out" },
    },
    {
      symbol: "×",
      color: "#4d82bc",
      style: { transform: "scale(1.2)", transition: "transform 0.3s ease-in-out" },
    },
    {
      symbol: "✗",
      color: "#005187",
      style: { transform: "skew(-10deg)", transition: "transform 0.3s ease-in-out" },
    },
    {
      symbol: "𝗫",
      color: "#005187",
      style: { opacity: 0.7, transition: "opacity 0.3s ease-in-out" },
    },
    {
      symbol: "✘",
      color: "#4d82bc",
      style: { transform: "translateY(-3px)", transition: "transform 0.3s ease-in-out" },
    },
  ]

  const [currentXAnimation, setCurrentXAnimation] = useState(xAnimations[0])

  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentXAnimation((prevAnim) => {
        const currentIndex = xAnimations.indexOf(prevAnim)
        const nextIndex = (currentIndex + 1) % xAnimations.length
        return xAnimations[nextIndex]
      })
    }, 1000)

    return () => clearInterval(interval)
  }, [])

  const services = [
    {
      title: "Servicios a tu Alcance",
      description: "Conectamos profesionales calificados con personas que necesitan servicios confiables.",
      image: "/placeholder.svg?height=500&width=800",
      icon: <CheckCircle className="feature-icon" size={24} />,
    },
    {
      title: "Profesionales Verificados",
      description: "Todos nuestros prestadores de servicios pasan por un riguroso proceso de verificación.",
      image: "/placeholder.svg?height=500&width=800",
      icon: <Shield className="feature-icon" size={24} />,
    },
    {
      title: "Garantía de Satisfacción",
      description: "Tu satisfacción es nuestra prioridad. Servicios garantizados y respaldados.",
      image: "/placeholder.svg?height=500&width=800",
      icon: <Clock className="feature-icon" size={24} />,
    },
  ]

  return (
    <section className="sec2" id="servicios">
      <div className="x-symbol-container">
        <span
          className={`animated-x ${currentXAnimation.symbol !== "X" ? "animate" : ""}`}
          style={{
            ...currentXAnimation.style,
            color: currentXAnimation.color,
          }}
        >
          {currentXAnimation.symbol}
        </span>
      </div>

      <Container>
        <Row className="text-center mb-5">
          <Col>
            <h2 className="section-title">Nuestros Servicios</h2>
            <p className="section-subtitle">Descubre cómo podemos ayudarte</p>
          </Col>
        </Row>

        <Row>
          <Col md={12} lg={6} className="mb-4 mb-lg-0">
            <Carousel className="services-carousel" indicators={true} controls={true}>
              {services.map((service, index) => (
                <Carousel.Item key={index}>
                  <div className="carousel-image-container">
                    <Image
                      src={service.image || "/placeholder.svg"}
                      alt={service.title}
                      width={800}
                      height={500}
                      className="d-block w-100 carousel-image"
                    />
                  </div>
                  <Carousel.Caption>
                    <h3>{service.title}</h3>
                    <p>{service.description}</p>
                  </Carousel.Caption>
                </Carousel.Item>
              ))}
            </Carousel>
          </Col>

          <Col md={12} lg={6}>
            <div className="services-cards">
              {services.map((service, index) => (
                <Card key={index} className="service-card mb-4">
                  <Card.Body className="d-flex">
                    <div className="service-icon-container">{service.icon}</div>
                    <div className="service-content">
                      <Card.Title>{service.title}</Card.Title>
                      <Card.Text>{service.description}</Card.Text>
                    </div>
                  </Card.Body>
                </Card>
              ))}
            </div>
          </Col>
        </Row>
      </Container>
    </section>
  )
}
